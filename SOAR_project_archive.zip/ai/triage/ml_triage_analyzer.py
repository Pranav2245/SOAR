#!/usr/bin/env python3
"""
Module 3.1: ML Triage Analyzer
===============================
Uses XGBoost to score incoming Wazuh alerts with a confidence level.
  - Score > 90%  → Auto-block (zero-touch)
  - Score 50-89% → Human review in TheHive
  - Score < 50%  → Auto-close as noise

Includes:
  - Synthetic training data generator
  - Model training pipeline
  - Prediction function for live alerts
"""

import json
import os
import pickle
import numpy as np
import pandas as pd
from datetime import datetime

try:
    from xgboost import XGBClassifier
except ImportError:
    print("Installing xgboost...")
    os.system("pip install xgboost")
    from xgboost import XGBClassifier

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score

MODEL_PATH = os.path.join(os.path.dirname(__file__), "triage_model.pkl")


def generate_synthetic_data(n_samples=10000) -> pd.DataFrame:
    """
    Generate comprehensive synthetic Wazuh alert data for training.
    Covers 20 attack types (including 8 password cracking variants)
    + normal operations with realistic distributions.
    """
    np.random.seed(42)
    data = []

    # --- ATTACK SCENARIOS (labeled as 1 = malicious) ---
    attack_types = {
        # 1. SSH Brute Force
        "brute_force": {
            "rule_level": (10, 14), "hour_of_day": (0, 6), "day_of_week": (0, 7),
            "failed_logins": (20, 150), "src_ip_is_internal": 0,
            "src_ip_reputation": (60, 100), "agent_os": [0, 1],
            "event_count_1h": (50, 300), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 2. Ransomware
        "ransomware": {
            "rule_level": (13, 15), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 3), "src_ip_is_internal": 0,
            "src_ip_reputation": (80, 100), "agent_os": [1],  # Mostly Windows
            "event_count_1h": (100, 500), "is_fim_event": 1, "has_mitre_tag": 1,
        },
        # 3. C2 Beacon (Command & Control)
        "c2_beacon": {
            "rule_level": (8, 12), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 1), "src_ip_is_internal": 0,
            "src_ip_reputation": (70, 100), "agent_os": [0, 1, 2],
            "event_count_1h": (10, 60), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 4. Data Exfiltration
        "data_exfil": {
            "rule_level": (10, 14), "hour_of_day": (0, 6), "day_of_week": (5, 7),
            "failed_logins": (0, 2), "src_ip_is_internal": 0,
            "src_ip_reputation": (30, 80), "agent_os": [0, 1],
            "event_count_1h": (20, 100), "is_fim_event": 1, "has_mitre_tag": 1,
        },
        # 5. Privilege Escalation
        "priv_esc": {
            "rule_level": (11, 15), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (3, 15), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 10), "agent_os": [0],  # Linux
            "event_count_1h": (5, 40), "is_fim_event": 1, "has_mitre_tag": 1,
        },
        # 6. Web Application Attack (SQLi, XSS, RFI)
        "web_attack": {
            "rule_level": (9, 13), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 2), "src_ip_is_internal": 0,
            "src_ip_reputation": (40, 95), "agent_os": [0],  # Linux web servers
            "event_count_1h": (30, 200), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 7. Lateral Movement
        "lateral_movement": {
            "rule_level": (10, 14), "hour_of_day": (0, 6), "day_of_week": (0, 7),
            "failed_logins": (5, 30), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 10), "agent_os": [0, 1],
            "event_count_1h": (20, 80), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 8. Rootkit / Persistence
        "rootkit": {
            "rule_level": (12, 15), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 1), "src_ip_is_internal": 0,
            "src_ip_reputation": (50, 100), "agent_os": [0],
            "event_count_1h": (5, 30), "is_fim_event": 1, "has_mitre_tag": 1,
        },
        # 9. Cryptomining
        "cryptomining": {
            "rule_level": (7, 11), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 1), "src_ip_is_internal": 0,
            "src_ip_reputation": (40, 80), "agent_os": [0],
            "event_count_1h": (50, 300), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 10. Phishing Click (user clicked malicious link)
        "phishing_click": {
            "rule_level": (8, 12), "hour_of_day": (8, 18), "day_of_week": (0, 5),
            "failed_logins": (0, 3), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 20), "agent_os": [1, 2],  # Windows/Mac workstations
            "event_count_1h": (5, 30), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 11. Insider Threat (unusual data access)
        "insider_threat": {
            "rule_level": (7, 11), "hour_of_day": (22, 24), "day_of_week": (5, 7),
            "failed_logins": (1, 5), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 5), "agent_os": [0, 1, 2],
            "event_count_1h": (10, 50), "is_fim_event": 1, "has_mitre_tag": 0,
        },
        # 12. DDoS / Flood Attack
        "ddos": {
            "rule_level": (10, 14), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 5), "src_ip_is_internal": 0,
            "src_ip_reputation": (50, 100), "agent_os": [0],
            "event_count_1h": (200, 500), "is_fim_event": 0, "has_mitre_tag": 1,
        },

        # ═══ PASSWORD CRACKING ATTACKS (8 types) ═══

        # 13. Dictionary Attack — tries common passwords from wordlists
        # Uses tools like John the Ripper, Hydra with rockyou.txt
        "dictionary_attack": {
            "rule_level": (10, 14), "hour_of_day": (0, 8), "day_of_week": (0, 7),
            "failed_logins": (30, 200), "src_ip_is_internal": 0,
            "src_ip_reputation": (55, 95), "agent_os": [0, 1],
            "event_count_1h": (80, 400), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 14. Credential Stuffing — uses breached username:password pairs
        # Automated tools replay leaked credentials across services
        "credential_stuffing": {
            "rule_level": (9, 13), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (10, 80), "src_ip_is_internal": 0,
            "src_ip_reputation": (50, 90), "agent_os": [0, 1],
            "event_count_1h": (40, 250), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 15. Password Spraying — tries a few common passwords against MANY users
        # Avoids account lockout by spreading across accounts
        "password_spraying": {
            "rule_level": (8, 12), "hour_of_day": (6, 22), "day_of_week": (0, 5),
            "failed_logins": (5, 20), "src_ip_is_internal": 0,
            "src_ip_reputation": (40, 85), "agent_os": [1],  # Targets Windows AD
            "event_count_1h": (100, 500), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 16. Kerberoasting — extracts Kerberos TGS tickets to crack offline
        # Targets Active Directory service accounts (MITRE T1558.003)
        "kerberoasting": {
            "rule_level": (11, 15), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 5), "src_ip_is_internal": 1,  # Internal attacker
            "src_ip_reputation": (0, 15), "agent_os": [1],  # Windows domain
            "event_count_1h": (5, 30), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 17. Pass-the-Hash (PtH) — uses stolen NTLM hashes to authenticate
        # No plaintext password needed, mimikatz-style (MITRE T1550.002)
        "pass_the_hash": {
            "rule_level": (12, 15), "hour_of_day": (0, 6), "day_of_week": (0, 7),
            "failed_logins": (0, 3), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 10), "agent_os": [1],  # Windows
            "event_count_1h": (3, 20), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 18. Rainbow Table / Offline Hash Cracking — precomputed hash lookup
        # Detected by monitoring for mass hash dump (SAM/NTDS.dit extraction)
        "rainbow_table_crack": {
            "rule_level": (13, 15), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 2), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 10), "agent_os": [1],
            "event_count_1h": (2, 15), "is_fim_event": 1, "has_mitre_tag": 1,
        },
        # 19. Keylogging / Credential Harvesting — captures keystrokes
        # Detected via suspicious process injection or FIM alerts
        "keylogging": {
            "rule_level": (10, 14), "hour_of_day": (8, 18), "day_of_week": (0, 5),
            "failed_logins": (0, 1), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 15), "agent_os": [1, 2],  # Windows/Mac endpoints
            "event_count_1h": (3, 20), "is_fim_event": 1, "has_mitre_tag": 1,
        },
        # 20. RDP Brute Force — targets Windows Remote Desktop Protocol
        # High event rate on port 3389 (MITRE T1110.001)
        "rdp_brute_force": {
            "rule_level": (10, 14), "hour_of_day": (0, 8), "day_of_week": (0, 7),
            "failed_logins": (25, 200), "src_ip_is_internal": 0,
            "src_ip_reputation": (55, 100), "agent_os": [1],  # Windows RDP
            "event_count_1h": (60, 350), "is_fim_event": 0, "has_mitre_tag": 1,
        },

        # ═══ NETWORK ATTACKS (4 types) ═══

        # 21. DNS Tunneling — hides data/C2 traffic inside DNS queries
        # Exfil via encoded subdomains (MITRE T1071.004)
        "dns_tunneling": {
            "rule_level": (9, 13), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 1), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 20), "agent_os": [0, 1],
            "event_count_1h": (100, 500), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 22. ARP Spoofing / Poisoning — redirects traffic by faking ARP
        # Man-in-the-middle on local network (MITRE T1557.002)
        "arp_spoofing": {
            "rule_level": (10, 14), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 0), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 10), "agent_os": [0, 1],
            "event_count_1h": (50, 200), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 23. Man-in-the-Middle (MITM) — intercepts network communication
        # SSL stripping, session hijacking (MITRE T1557)
        "mitm_attack": {
            "rule_level": (11, 15), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 2), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 15), "agent_os": [0, 1, 2],
            "event_count_1h": (20, 80), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 24. Port Scanning / Reconnaissance — mapping open services
        # Nmap, Masscan probing (MITRE T1046)
        "port_scan": {
            "rule_level": (7, 11), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 3), "src_ip_is_internal": 0,
            "src_ip_reputation": (30, 80), "agent_os": [0, 1],
            "event_count_1h": (100, 500), "is_fim_event": 0, "has_mitre_tag": 1,
        },

        # ═══ APPLICATION ATTACKS (3 types) ═══

        # 25. Supply Chain Attack — compromised dependency/update
        # Malicious package injected into build pipeline (MITRE T1195)
        "supply_chain": {
            "rule_level": (13, 15), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 1), "src_ip_is_internal": 0,
            "src_ip_reputation": (20, 60), "agent_os": [0, 1],
            "event_count_1h": (5, 30), "is_fim_event": 1, "has_mitre_tag": 1,
        },
        # 26. Zero-Day Exploit — exploiting unknown vulnerability
        # No patch available, unusual process behavior (MITRE T1203)
        "zero_day": {
            "rule_level": (14, 15), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 2), "src_ip_is_internal": 0,
            "src_ip_reputation": (60, 100), "agent_os": [0, 1, 2],
            "event_count_1h": (3, 20), "is_fim_event": 1, "has_mitre_tag": 1,
        },
        # 27. API Abuse / Broken Auth — mass API endpoint exploitation
        # Rate abuse, token manipulation (OWASP API Top 10)
        "api_abuse": {
            "rule_level": (8, 12), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (5, 50), "src_ip_is_internal": 0,
            "src_ip_reputation": (30, 75), "agent_os": [0],  # API servers
            "event_count_1h": (100, 400), "is_fim_event": 0, "has_mitre_tag": 1,
        },

        # ═══ ADVANCED PERSISTENT THREATS (3 types) ═══

        # 28. Fileless Malware — executes in memory, no disk write
        # PowerShell/WMI abuse, hard to detect (MITRE T1059.001)
        "fileless_malware": {
            "rule_level": (12, 15), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 1), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 15), "agent_os": [1],  # Windows PowerShell
            "event_count_1h": (3, 25), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 29. Watering Hole — compromises a website the target visits
        # Infects trusted sites to target specific orgs (MITRE T1189)
        "watering_hole": {
            "rule_level": (10, 14), "hour_of_day": (8, 18), "day_of_week": (0, 5),
            "failed_logins": (0, 1), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 25), "agent_os": [1, 2],  # Workstations
            "event_count_1h": (3, 15), "is_fim_event": 0, "has_mitre_tag": 1,
        },
        # 30. Reverse Shell — attacker gets remote shell on victim
        # Netcat, Metasploit callback (MITRE T1059)
        "reverse_shell": {
            "rule_level": (13, 15), "hour_of_day": (0, 24), "day_of_week": (0, 7),
            "failed_logins": (0, 1), "src_ip_is_internal": 1,
            "src_ip_reputation": (0, 20), "agent_os": [0, 1],
            "event_count_1h": (2, 10), "is_fim_event": 0, "has_mitre_tag": 1,
        },
    }

    # Generate attack samples
    samples_per_attack = n_samples // 5 // len(attack_types)
    for attack_name, profile in attack_types.items():
        for _ in range(max(samples_per_attack, 50)):
            rl = profile["rule_level"]
            hod = profile["hour_of_day"]
            fl = profile["failed_logins"]
            srep = profile["src_ip_reputation"]

            row = {
                "rule_level": np.random.randint(rl[0], rl[1] + 1),
                "hour_of_day": np.random.randint(hod[0], min(hod[1], 24)),
                "day_of_week": np.random.randint(profile["day_of_week"][0], profile["day_of_week"][1]),
                "failed_logins": np.random.randint(fl[0], fl[1] + 1),
                "src_ip_is_internal": profile["src_ip_is_internal"],
                "src_ip_reputation": np.random.randint(srep[0], srep[1] + 1) if isinstance(srep, tuple) else srep,
                "agent_os": int(np.random.choice(profile["agent_os"])),
                "event_count_1h": np.random.randint(profile["event_count_1h"][0], profile["event_count_1h"][1] + 1),
                "is_fim_event": profile["is_fim_event"],
                "has_mitre_tag": profile["has_mitre_tag"],
                "label": 1,  # Malicious
            }
            data.append(row)

    # --- NORMAL OPERATIONS (labeled as 0 = benign) ---
    normal_scenarios = {
        "routine_login": {
            "rule_level": (1, 5), "hour_of_day": (7, 19), "failed_logins": (0, 2),
            "src_ip_is_internal": 1, "src_ip_reputation": (0, 5),
            "event_count_1h": (1, 30), "is_fim_event": 0, "has_mitre_tag": 0,
        },
        "system_update": {
            "rule_level": (3, 7), "hour_of_day": (2, 5), "failed_logins": (0, 0),
            "src_ip_is_internal": 1, "src_ip_reputation": (0, 0),
            "event_count_1h": (10, 80), "is_fim_event": 1, "has_mitre_tag": 0,
        },
        "developer_activity": {
            "rule_level": (2, 6), "hour_of_day": (9, 20), "failed_logins": (0, 3),
            "src_ip_is_internal": 1, "src_ip_reputation": (0, 5),
            "event_count_1h": (5, 60), "is_fim_event": 1, "has_mitre_tag": 0,
        },
        "admin_tasks": {
            "rule_level": (3, 8), "hour_of_day": (8, 18), "failed_logins": (0, 2),
            "src_ip_is_internal": 1, "src_ip_reputation": (0, 5),
            "event_count_1h": (3, 40), "is_fim_event": 0, "has_mitre_tag": 0,
        },
        "monitoring_noise": {
            "rule_level": (1, 4), "hour_of_day": (0, 24), "failed_logins": (0, 1),
            "src_ip_is_internal": 1, "src_ip_reputation": (0, 0),
            "event_count_1h": (1, 15), "is_fim_event": 0, "has_mitre_tag": 0,
        },
        "vpn_login": {
            "rule_level": (3, 6), "hour_of_day": (6, 22), "failed_logins": (0, 3),
            "src_ip_is_internal": 0, "src_ip_reputation": (0, 15),
            "event_count_1h": (1, 10), "is_fim_event": 0, "has_mitre_tag": 0,
        },
        "backup_job": {
            "rule_level": (2, 5), "hour_of_day": (1, 5), "failed_logins": (0, 0),
            "src_ip_is_internal": 1, "src_ip_reputation": (0, 0),
            "event_count_1h": (20, 100), "is_fim_event": 1, "has_mitre_tag": 0,
        },
        "ci_cd_pipeline": {
            "rule_level": (2, 6), "hour_of_day": (0, 24), "failed_logins": (0, 1),
            "src_ip_is_internal": 1, "src_ip_reputation": (0, 5),
            "event_count_1h": (10, 120), "is_fim_event": 1, "has_mitre_tag": 0,
        },
    }

    # Generate normal samples to balance the dataset
    normal_per_type = (n_samples - len(data)) // len(normal_scenarios)
    for scenario_name, profile in normal_scenarios.items():
        for _ in range(max(normal_per_type, 100)):
            rl = profile["rule_level"]
            hod = profile["hour_of_day"]
            fl = profile["failed_logins"]
            srep = profile["src_ip_reputation"]

            row = {
                "rule_level": np.random.randint(rl[0], rl[1] + 1),
                "hour_of_day": np.random.randint(hod[0], min(hod[1], 24)),
                "day_of_week": np.random.randint(0, 7),
                "failed_logins": np.random.randint(fl[0], fl[1] + 1),
                "src_ip_is_internal": profile["src_ip_is_internal"],
                "src_ip_reputation": np.random.randint(srep[0], srep[1] + 1),
                "agent_os": int(np.random.choice([0, 1, 2])),
                "event_count_1h": np.random.randint(profile["event_count_1h"][0], profile["event_count_1h"][1] + 1),
                "is_fim_event": profile["is_fim_event"],
                "has_mitre_tag": profile["has_mitre_tag"],
                "label": 0,  # Benign
            }
            data.append(row)

    return pd.DataFrame(data)


def train_model():
    """Train an XGBoost classifier on synthetic alert data."""
    print("[*] Generating synthetic training data...")
    df = generate_synthetic_data(2000)

    features = [
        "rule_level", "hour_of_day", "day_of_week",
        "failed_logins", "src_ip_is_internal", "src_ip_reputation",
        "agent_os", "event_count_1h", "is_fim_event", "has_mitre_tag"
    ]

    X = df[features]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    print("[*] Training XGBoost classifier...")
    model = XGBClassifier(
        n_estimators=100,
        max_depth=5,
        learning_rate=0.1,
        use_label_encoder=False,
        eval_metric='logloss',
        random_state=42
    )
    model.fit(X_train, y_train)

    # Evaluate
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    print("\n[+] === Model Evaluation ===")
    print(classification_report(y_test, y_pred, target_names=["Benign", "Malicious"]))
    print(f"ROC AUC Score: {roc_auc_score(y_test, y_proba):.4f}")

    # Save model
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(model, f)
    print(f"[+] Model saved to {MODEL_PATH}")

    return model


def predict_threat(alert_data: dict) -> dict:
    """
    Predict the threat confidence score for a Wazuh alert.

    Args:
        alert_data: Dict with keys matching the feature names.

    Returns:
        Dict with confidence_score, decision, and details.
    """
    if not os.path.exists(MODEL_PATH):
        print("[!] No trained model found. Training now...")
        train_model()

    with open(MODEL_PATH, 'rb') as f:
        model = pickle.load(f)

    features = pd.DataFrame([{
        "rule_level": alert_data.get("rule_level", 5),
        "hour_of_day": alert_data.get("hour_of_day", datetime.now().hour),
        "day_of_week": alert_data.get("day_of_week", datetime.now().weekday()),
        "failed_logins": alert_data.get("failed_logins", 0),
        "src_ip_is_internal": alert_data.get("src_ip_is_internal", 1),
        "src_ip_reputation": alert_data.get("src_ip_reputation", 0),
        "agent_os": alert_data.get("agent_os", 0),
        "event_count_1h": alert_data.get("event_count_1h", 1),
        "is_fim_event": alert_data.get("is_fim_event", 0),
        "has_mitre_tag": alert_data.get("has_mitre_tag", 0),
    }])

    confidence = float(model.predict_proba(features)[0][1]) * 100

    # Decision logic
    if confidence >= 90:
        decision = "AUTO_BLOCK"
        action = "Automatically blocked. Zero-touch response triggered."
    elif confidence >= 50:
        decision = "HUMAN_REVIEW"
        action = "Escalated to SOC analyst for manual review in TheHive."
    else:
        decision = "AUTO_CLOSE"
        action = "Closed as noise. No action required."

    return {
        "confidence_score": round(confidence, 2),
        "decision": decision,
        "action": action,
        "features_used": features.to_dict(orient='records')[0]
    }


# --- Cortex Analyzer Interface ---
def run_as_cortex_analyzer():
    """Run as a Cortex analyzer (reads from stdin)."""
    import sys
    input_data = sys.stdin.read()
    if not input_data:
        print(json.dumps({"success": False, "errorMessage": "No input"}))
        sys.exit(1)

    job = json.loads(input_data)
    observable = job.get("observable", {}).get("data", "")

    # Parse the alert data from the observable or job config
    alert_features = job.get("parameters", {}).get("alert_features", {})
    if not alert_features:
        alert_features = {"rule_level": 10, "failed_logins": 5}

    result = predict_threat(alert_features)

    level = "malicious" if result["decision"] == "AUTO_BLOCK" else \
            "suspicious" if result["decision"] == "HUMAN_REVIEW" else "safe"

    output = {
        "success": True,
        "summary": {
            "taxonomies": [{
                "level": level,
                "namespace": "MLTriage",
                "predicate": "Confidence",
                "value": f"{result['confidence_score']}%"
            }]
        },
        "full": result
    }
    print(json.dumps(output))


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--train":
        train_model()
    elif len(sys.argv) > 1 and sys.argv[1] == "--test":
        test_alert = {
            "rule_level": 12,
            "hour_of_day": 3,
            "failed_logins": 50,
            "src_ip_is_internal": 0,
            "src_ip_reputation": 85,
            "agent_os": 0,
            "event_count_1h": 120,
            "is_fim_event": 0,
            "has_mitre_tag": 1
        }
        result = predict_threat(test_alert)
        print(json.dumps(result, indent=2))
    else:
        run_as_cortex_analyzer()
